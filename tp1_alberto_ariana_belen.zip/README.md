# TP 1 - Descripción del trabajo realizado.
En el presente trabajo se realizó un currículum en base a mí experiencia laboral como diseñadora e ilustradora. En un principio fue pensado para ser dividido en distintos archivos HTML, pero por el momento se decidió dejar toda la información en uno solo.
Se trató de buscar una clara división entre lo que es el Header, el Main y el Footer (incluyendo contenidos internos). Se utilizaron los siguientes recursos visuales: JPG, PNG y SVG.
Se incorporó un navegador pensado para futuros cambios en caso de desarrollar aún más el curriculum.
El uso de Flexbox ayudó a ordenar los contenidos aunque al principio hubieron complicaciones para comprenderlo (más especificamente por la cantidad de las etiquetas utilizadas).

Tamaño de pantalla: 1360 x 768
Editor de código: Visual Studio Code

